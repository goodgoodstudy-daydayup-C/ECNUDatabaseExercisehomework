import java.sql.*;

public class SearchTeachers {
    public static void main(String[] args) {
        // Get user input for loginID and password
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter loginID: ");
        String loginID = scanner.nextLine();
        System.out.print("Enter password: ");
        String password = scanner.nextLine();

        // Connect to database
        Connection conn = null;
        PreparedStatement stmt = null;
        try {
            String dbUrl = "jdbc:postgresql://localhost:15432/db2022";
            String dbUser = "gaussdb";
            String dbPassword = "Password@123";
            conn = DriverManager.getConnection(dbUrl, dbUser, dbPassword);

            // Get user input for search substring
            System.out.print("Enter search substring: ");
            String substring = scanner.nextLine();

            // Search for teachers with name matching the substring
            String sql = "SELECT ID, name FROM teachers WHERE name LIKE substring";
            stmt = conn.prepareStatement(sql);
            stmt.setString(1, "%" + substring + "%");
            ResultSet rs = stmt.executeQuery();

            // Print the search results
            while (rs.next()) {
                int id = rs.getInt("ID");
                String name = rs.getString("name");
                System.out.println("ID: " + id + ", name: " + name);
            }
            // Prompt the user to enter a teacher ID
            System.out.print("Enter a teacher ID (0-99999): ");
            int teacherId = Integer.parseInt(System.console().readLine());

            // Check if the teacher exists
            stmt = conn.createStatement();
            String sql = "SELECT * FROM teacher WHERE teacher_id = " + teacherId;
            ResultSet rs = stmt.executeQuery(sql);

            if (!rs.next()) {
                System.out.println("No teacher with the specified ID was found");
            } else {
                // Print the teacher's record
                String teacherName = rs.getString("teacher_name");
                System.out.println("Teacher ID: " + teacherId);
                System.out.println("Teacher name: " + teacherName);

                // Check if the teacher has taught any courses
                sql = "SELECT * FROM teaches WHERE teacher_id = " + teacherId;
                rs = stmt.executeQuery(sql);

                if (!rs.next()) {
                    System.out.println("The teacher has not taught any courses.");
                } else {
                    // Print the teacher's course records
                    System.out.println("Department\tCourse ID\tCourse Title\tChapter\tSemester\tYear\tEnrollment");
                    System.out.println("--------------------------------------------------------------------------------------");

                    do {
                        int courseId = rs.getInt("course_id");
                        String semester = rs.getString("semester");
                        int year = rs.getInt("year");
                        int section = rs.getInt("section");

                        // Retrieve course information
                        sql = "SELECT * FROM course WHERE course_id = " + courseId;
                        ResultSet courseRs = stmt.executeQuery(sql);

                        if (courseRs.next()) {
                            String deptName = courseRs.getString("dept_name");
                            String courseTitle = courseRs.getString("title");

                            // Retrieve enrollment information
                            sql = "SELECT COUNT(*) as enrollment FROM takes WHERE course_id = " + courseId
                                    + " AND semester = '" + semester + "' AND year = " + year
                                    + " AND section = " + section;
                            ResultSet enrollmentRs = stmt.executeQuery(sql);

                            if (enrollmentRs.next()) {
                                int enrollment = enrollmentRs.getInt("enrollment");
                                System.out.println(deptName + "\t\t" + courseId + "\t\t" + courseTitle + "\t\t" + section
                                        + "\t\t" + semester + "\t\t" + year + "\t" + enrollment);
                            }
                        }

                    } while (rs.next());
                }
            }

            // Clean-up environment
            rs.close();
            stmt.close();
            conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            // Close database resources
            try {
                if (stmt != null) stmt.close();
                if (conn != null) conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}
